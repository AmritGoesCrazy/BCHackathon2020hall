//package Horror_Maze;

public class Player {
	
	private int age;
	private String name;
	private int killChance;
	private int playerY;
	private String[] weapons = {"Knife", "Hammer", "Golden Spoon", "Shotgun", "Pliers", "Baseball Bat"};
	
	
	public int getKillChance() {
		return killChance;
	}
	public void setKillChance(int killChance) {
		this.killChance = killChance;
	}
	public int getPlayerY() {
		return playerY;
	}
	public void setPlayerY(int playerY) {
		this.playerY = playerY;
	}
	
	
	public Player(int age, String name) {
		this.age = age;
		this.name = name;
		this.killChance = 0;
		this.playerY = 2;
		
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getWeapons() {
		return weapons;
	}
	public void setWeapons(String[] weapons) {
		this.weapons = weapons;
	}


}
