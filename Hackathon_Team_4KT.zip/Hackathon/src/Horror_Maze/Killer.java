//package Horror_Maze;

public class Killer {
	private String name;
	private String weapon;
	private String[] killers = {"Michael Myers", "Jason Voorhees", "Freddy Kreuger"};
	private String[] weapons = {"Knife", "Machete", "Killer Glove"};
	private int killerY;
	
	public int getKillerY() {
		return killerY;
	}

	public void setKillerY(int killerY) {
		this.killerY = killerY;
	}

	public Killer(int num) {
		if(num == 0) {
			this.name = killers[0];
			this.weapon = weapons[0];
			this.killerY = 0;
		}else if(num == 1) {
			this.name = killers[1];
			this.weapon = weapons[1];
			this.killerY = 0;
		}else {
			this.name = killers[2];
			this.weapon = weapons[2];
			this.killerY = 0;
		}
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}

}
