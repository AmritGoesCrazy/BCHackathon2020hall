//package Horror_Maze;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class Maze_Main {

	public static void main(String[] args) throws InterruptedException {
	
		Scanner in = new Scanner(System.in);
		System.out.print("What is your name? ");
		String name = in.nextLine();
		Player p = new Player(0, name);
		int random = (int)(Math.random() * 3);
		Killer k = new Killer(random);
		int steps = p.getPlayerY() - k.getKillerY();
		TimeUnit.SECONDS.sleep(2);
		System.out.println("\nWATCH OUT " + name + ", there's a killer on the loose!");
		TimeUnit.SECONDS.sleep(3);
		
		if(k.getName().equals("Michael Myers")) {
			System.out.println("\nHe escaped from a psychiatric hospital after 15 years of captivity!\nHe supposedly goes by the name of Michael Myers and is hell bent on killing anyone in his way!");
		}else if(k.getName().equals("Jason Voorhees")) {
			System.out.println("\nHe roams the campground looking for the counsellors who killed his mother.\nHe must think you're one of them and is coming to kill you! He supposedly goes by the name of Jason Voorhees.");
		}else 
			System.out.println("\nHe uses a gloved hand with razors to kill his victims in their dreams, \ncausing their deaths in the real world as well. He supposedly goes by the name of Freddy Krueger!");
		
		TimeUnit.SECONDS.sleep(8);
		System.out.println("\nHe appears to be rocking a " + k.getWeapon());
		TimeUnit.SECONDS.sleep(3);
		
		Game(p, k);
		
		System.out.println(k.getName() + " has caught up to you and slashed you with a " + k.getWeapon() + "!");
		TimeUnit.SECONDS.sleep(3);
		System.out.println("...");
		TimeUnit.SECONDS.sleep(1);
		System.out.println("You are dead! GAME OVER");
		

	}
	
	
	public static void Game(Player p, Killer k) throws InterruptedException{
		while(p.getPlayerY() != k.getKillerY()) {
			Direction(p, k);
			Check(p, k);
		}
		
	
	}
	public static void Knife(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Knife!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance() + 20);
		System.out.println("\nYour chance to kill has increased by 20! Your total kill chance is " + p.getKillChance());
	}
	
	public static void Hammer(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Hammer!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance() + 15);
		System.out.println("\nYour chance to kill has increased by 15! Your total kill chance is " + p.getKillChance());
	}
	
	public static void GoldenSpoon(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Golden Spoon!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance() + 1);
		System.out.println("\nYour chance to kill has increased by 1! Your total kill chance is " + p.getKillChance());
	}
	
	public static void Shotgun(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Shotgun!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance() + 49);
		System.out.println("\nYour chance to kill has increased by 49! Your total kill chance is " + p.getKillChance());
	}
	
	public static void Pliers(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Pliers!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance() + 8);
		System.out.println("\nYour chance to kill has increased by 8! Your total kill chance is " + p.getKillChance());
	}
	
	public static void Bat(Player p, Killer k) throws InterruptedException {
		System.out.println("You picked up the Bat!");
		TimeUnit.SECONDS.sleep(2);
		p.setKillChance(p.getKillChance()+10);
		System.out.println("\nYour chance to kill has increased by 10! Your total kill chance is " + p.getKillChance());
	}
	
	public static void moveLeft(Player p, Killer k) {
		p.setPlayerY(p.getPlayerY() +1);
		k.setKillerY(k.getKillerY() +2);
		
	}
	public static void moveRight(Player p, Killer k) {
		p.setPlayerY(p.getPlayerY() +1);
		k.setKillerY(k.getKillerY() +2);
	}
	public static void Move(Player p, Killer k) {
		p.setPlayerY(p.getPlayerY() + 2);
		k.setKillerY(k.getKillerY() +1);
	}
	
	
	 public static void Farmhouse(Player p, Killer k) throws InterruptedException {
	        Scanner in = new Scanner(System.in);
	        System.out.println("You see a farmhouse along the way, would you like to search it? (y/n) ");
	        String ans = in.nextLine();
	        if(ans.equals("n")) {
	            return;
	        }else {
	            TimeUnit.SECONDS.sleep(2);
	            System.out.println("In the farmhouse, you find a Hammer, and a Bat. What would you like to pick up? (h/b)");
	            String ans1 = in.nextLine();
	            if(ans1.equals("h")) {
	                Hammer(p,k);
	            }
	            else {
	                Bat(p,k);
	            }
	            Attack(p, k);
	        }
	    }
	 public static void Cabin(Player p, Killer k) throws InterruptedException {
	        Scanner in = new Scanner(System.in);
	        System.out.println("You see a cabin along the way, would you like to search it? (y/n) ");
	        String ans = in.nextLine();
	        if(ans.equals("n")) {
	            return;
	        }else {
	            TimeUnit.SECONDS.sleep(2);
	            System.out.println("In the cabin, you find a Knife, and a Pliers. What would you like to pick up? (k/p)");
	            String ans1 = in.nextLine();
	            if(ans1.equals("k")) {
	                Knife(p,k);
	            }
	            else {
	                Pliers(p,k);
	            }
	            Attack(p, k);
	        }
	    }
	 
	    public static void Shack(Player p, Killer k) throws InterruptedException {
	        Scanner in = new Scanner(System.in);
	        System.out.println("You see a shack along the way, would you like to search it? (y/n) ");
	        String ans = in.nextLine();
	        if(ans.equals("n")) {
	            return;
	        }else {
	            TimeUnit.SECONDS.sleep(2);
	            System.out.println("In the shack, you find a Shotgun, and a Golden Spoon. What would you like to pick up? (s/gs)");
	            String ans1 = in.nextLine();
	            if(ans1.equals("s")) {
	                Shotgun(p,k);
	            }
	            else {
	                GoldenSpoon(p,k);
	            }
	            Attack(p, k);
	        }
	    }
	
	public static void Check(Player p, Killer k) throws InterruptedException{
		if((p.getPlayerY() % 3) == 0) {
			Cabin(p, k);
		}else if((p.getPlayerY() % 7) == 0) {
			Farmhouse(p, k);
		}else if((p.getPlayerY() % 11) == 0) 
			Shack(p, k);
	}
	
	public static void Direction(Player p, Killer k) throws InterruptedException{
		Scanner in = new Scanner(System.in);
		System.out.println("\nHe's " + (p.getPlayerY() - k.getKillerY()) + " steps behind you! ");
		System.out.println("What do you wanna do? Turn Left, turn Right, or go Straight? (l/r/s)");
		String direction = in.nextLine();
		if(direction.equals("l")) {
			moveLeft(p,k);
		}else if(direction.equals("r")) {
			moveRight(p,k);
		}else 
			Move(p,k);
	}
	
	public static void Attack(Player p, Killer k) {
		Scanner in = new Scanner(System.in);
		System.out.println("\nWould you like to take the chance to attack " + k.getName() + "? (y/n)");
		String ans = in.nextLine();
		if(ans.equals("n"))
			return;
		else {
		if(p.getKillChance() < 50) {
			System.out.println(k.getName() + " has murdered you with a " + k.getWeapon() + "! GAME OVER");
			p.setPlayerY(0);
			k.setKillerY(0);
		}else 
			System.out.println("You killed " + k.getName() + "! GAME OVER");
		p.setPlayerY(0);
		k.setKillerY(0);
		}
	}

}
